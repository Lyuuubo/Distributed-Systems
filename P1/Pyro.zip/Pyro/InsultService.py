import Pyro4    
import random
import time
from multiprocessing import Process

@Pyro4.expose   
class InsultService:
    def __init__(self):
        self.insults = []
        self.subscribers = []
        self.process = None
           
    def add_insults(self, insult):
        if insult not in self.insults:
            self.insults.append(insult)
    
    def add_subscriber(self, subscriber):
        if subscriber not in self.subscribers:
            self.subscribers.append(subscriber)
            print(f"New subsriber {subscriber}")
        
    def notify_server(self, insult):
        for subscriber in self.subscribers:
            sub = Pyro4.Proxy(subscriber)
            #Add insult in each server if they don't have it yet
            sub.notify(insult) 

    def remove_subscriber(self, subscriber):
        if subscriber in self.subscribers:
            self.subsribers.remove(subscriber)

    def notify(self, insult):
        self.add_insults(insult)

    def  get_insults(self):
        return self.insults
    
    def random_insult(self):
        return random.choice(self.insults)
    
    def get_subscribers(self):
        return self.subsribers
    
    def random_events(self):
        if self.process is None:
            self.process = Process(target=self.auxiliar_random_events)
            self.process.start()

    def auxiliar_random_events(self):
        while True:
            for subscriber in self.subscribers:
                sub = Pyro4.Proxy(subscriber)
                sub.notify(self.random_insult())
            time.sleep(5)

    def kill_random_events(self):
        if self.process.is_alive():
            self.process.kill()
            self.process.join()
            self.process = None


daemon = Pyro4.Daemon(host='localhost')
ns = Pyro4.locateNS(host='localhost', port=9090)
uri = daemon.register(InsultService)
ns.register('insult.service', uri)
print(f"Server uri: {uri}")
daemon.requestLoop()