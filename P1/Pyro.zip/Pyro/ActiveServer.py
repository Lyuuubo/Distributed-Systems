import Pyro4.naming

Pyro4.naming.startNSloop()