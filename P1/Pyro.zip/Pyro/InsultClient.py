import Pyro4
import random

@Pyro4.expose
class InsultClient:
    def __init__(self):
        self.insults = []

    def notify(self, insult):
        print(f"Recived insult{insult}")

daemon = Pyro4.Daemon(host='localhost')
ns = Pyro4.locateNS(host='localhost', port=9090)
uri = ns.lookup('insult.service')
server = Pyro4.Proxy(uri)
client = daemon.register(InsultClient)
print(f"Fiumba {client}")
server.add_subscriber(client)
server.add_insults("Cap d'escrot")
server.add_insults("Cavero")
server.add_insults("Maduro")
server.add_insults("Fiumba")
print(server.get_insults())
server.random_events()
daemon.requestLoop()